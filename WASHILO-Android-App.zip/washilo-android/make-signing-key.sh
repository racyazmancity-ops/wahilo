#!/usr/bin/env bash
# Creates a permanent signing key for the WASHILO app and prints the values
# to paste into GitHub → Settings → Secrets and variables → Actions.
# Keep washilo.jks and the password safe: you need the same key for every update.
set -e
read -rsp "Choose a key password (min 6 chars): " PASS; echo
keytool -genkeypair -v -keystore washilo.jks -alias washilo -keyalg RSA -keysize 2048 \
  -validity 10000 -storepass "$PASS" -keypass "$PASS" \
  -dname "CN=WASHILO, O=WASHILO, C=PK"
echo
echo "KEYSTORE_BASE64 ="; base64 -w0 washilo.jks 2>/dev/null || base64 washilo.jks; echo
echo "KEYSTORE_PASSWORD = (the password you chose)"
echo "KEY_ALIAS = washilo"
echo "KEY_PASSWORD = (the same password)"
