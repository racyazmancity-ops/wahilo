# WASHILO Android app

An Android app that opens **https://washilo.xo.je/** full screen, with:

- WASHILO icon and splash screen, top loading bar, pull down to refresh
- Camera for the rider/outlet QR scanner and item photos (asks permission the first time)
- Location for "Find my nearest outlet"
- Phone numbers, WhatsApp, Google Maps, email and payment pages open in the right app
- washilo.xo.je links (tracking links, QR labels) open inside the app
- Offline screen with "Try again", back button goes back through pages
- Stays logged in between launches

Package name `com.washilo.app`, Android 6.0 and newer. To point it at another domain, edit `siteUrl` and `siteHost` at the top of `app/build.gradle.kts`.

## Get the APK without installing anything (GitHub, free)

1. Create a free account at github.com, then **New repository** → name it `washilo-android` → Create.
2. On the new repo page click **uploading an existing file**, drag in **all files and folders from this zip** (including the `.github` folder), and click **Commit changes**.
   - If your file picker hides `.github`, create the file manually: **Add file → Create new file**, name it `.github/workflows/build-apk.yml`, and paste the contents of that file.
3. Open the **Actions** tab. The "Build WASHILO APK" job starts automatically and takes about 5 minutes.
4. When it shows a green tick, open the run and download **WASHILO-app** at the bottom. Unzip it: `WASHILO.apk` is the app, `WASHILO.aab` is for the Google Play Store.
5. Send `WASHILO.apk` to your phone and open it. Allow "Install unknown apps" when Android asks.

## Keep the same signature for updates (do this before sharing the app)

Without a permanent key, every build gets a new temporary signature, so people have to uninstall before installing a newer build. To fix that once:

1. On any computer with Java, run `./make-signing-key.sh` (or the `keytool` command inside it).
2. In GitHub → your repo → **Settings → Secrets and variables → Actions**, add `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` (`washilo`) and `KEY_PASSWORD` with the values it prints.
3. Keep `washilo.jks` and the password somewhere safe. Google Play needs the same key for every update.

Every push to `main` builds a new APK. Pushing a tag like `v1.0.1` also attaches the APK to a GitHub Release, which gives you a permanent download link.

## Build with Android Studio instead

Open this folder in Android Studio → let it sync → **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.

## Notes

- The app shows the live website, so changes to the WordPress site appear in the app straight away; no app update needed.
- Free hosting (such as the host behind washilo.xo.je) sometimes shows a browser check page or blocks apps. If the app shows a blank page or a security check that loops, move the site to paid hosting with HTTPS.
- For Google Play you also need a privacy policy page on the website and the screenshots/listing in Play Console.
