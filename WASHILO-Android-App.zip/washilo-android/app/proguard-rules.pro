# No custom rules needed: the app uses only Android framework and AndroidX classes.
